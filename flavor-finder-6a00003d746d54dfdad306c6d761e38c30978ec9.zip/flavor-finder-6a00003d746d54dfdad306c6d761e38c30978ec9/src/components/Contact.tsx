import { Button } from "@/components/ui/button";
import { MapPin, Phone, Clock } from "lucide-react";

const Contact = () => {
  return (
    <section id="contact" className="py-20 bg-muted">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16 animate-in fade-in duration-700">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Visit Us
          </h2>
          <p className="text-lg text-muted-foreground">
            We'd love to welcome you to Savoria
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 max-w-5xl mx-auto">
          {/* Contact Info */}
          <div className="space-y-8 animate-in slide-in-from-left-4 duration-700">
            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                <MapPin className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-1">Location</h3>
                <p className="text-muted-foreground">
                  123 Culinary Boulevard<br />
                  Downtown District, City 12345
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                <Phone className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-1">Phone</h3>
                <p className="text-muted-foreground">
                  +1 (555) 123-4567<br />
                  reservations@savoria.com
                </p>
              </div>
            </div>

            <div className="flex items-start gap-4">
              <div className="w-12 h-12 bg-primary/10 rounded-full flex items-center justify-center flex-shrink-0">
                <Clock className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-semibold text-lg mb-1">Hours</h3>
                <p className="text-muted-foreground">
                  Tuesday - Saturday: 5:00 PM - 11:00 PM<br />
                  Sunday: 5:00 PM - 10:00 PM<br />
                  Monday: Closed
                </p>
              </div>
            </div>
          </div>

          {/* Reservation CTA */}
          <div className="bg-card p-8 rounded-lg shadow-elegant flex flex-col justify-center animate-in slide-in-from-right-4 duration-700">
            <h3 className="text-2xl font-bold mb-4">Make a Reservation</h3>
            <p className="text-muted-foreground mb-6">
              Book your table for an unforgettable dining experience. We recommend reserving in advance, 
              especially for weekend dining.
            </p>
            <Button size="lg" className="w-full">
              Book Now
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
