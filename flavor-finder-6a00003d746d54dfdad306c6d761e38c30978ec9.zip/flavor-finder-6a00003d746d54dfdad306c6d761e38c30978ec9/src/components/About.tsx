import { Award, Heart, Users } from "lucide-react";

const About = () => {
  return (
    <section id="about" className="py-20 bg-muted">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16 animate-in fade-in duration-700">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Our Story
          </h2>
          <p className="text-lg text-muted-foreground leading-relaxed">
            Founded in 2010, Savoria has been a beacon of culinary excellence in the heart of the city. 
            Our passionate chefs craft each dish with locally-sourced ingredients and time-honored techniques, 
            creating unforgettable dining experiences that celebrate the art of gastronomy.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          <div className="bg-card p-8 rounded-lg shadow-elegant text-center hover:shadow-glow transition-all duration-300 animate-in slide-in-from-bottom-4 duration-700">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Award className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Award Winning</h3>
            <p className="text-muted-foreground">
              Recognized for excellence in fine dining and culinary innovation
            </p>
          </div>

          <div className="bg-card p-8 rounded-lg shadow-elegant text-center hover:shadow-glow transition-all duration-300 animate-in slide-in-from-bottom-4 duration-700 delay-150">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Heart className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Made with Love</h3>
            <p className="text-muted-foreground">
              Every dish is prepared with passion and attention to detail
            </p>
          </div>

          <div className="bg-card p-8 rounded-lg shadow-elegant text-center hover:shadow-glow transition-all duration-300 animate-in slide-in-from-bottom-4 duration-700 delay-300">
            <div className="w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mx-auto mb-4">
              <Users className="w-8 h-8 text-primary" />
            </div>
            <h3 className="text-xl font-semibold mb-2">Family Friendly</h3>
            <p className="text-muted-foreground">
              A warm, welcoming atmosphere for guests of all ages
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
