const Footer = () => {
  return (
    <footer className="bg-secondary text-secondary-foreground py-8">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-2xl font-bold mb-4">Savoria</h2>
        <p className="text-secondary-foreground/80 mb-4">
          Experience the art of fine dining
        </p>
        <p className="text-sm text-secondary-foreground/60">
          © 2024 Savoria Restaurant. All rights reserved.
        </p>
      </div>
    </footer>
  );
};

export default Footer;
