import { Card, CardContent } from "@/components/ui/card";
import pastaImage from "@/assets/dish-pasta.jpg";
import steakImage from "@/assets/dish-steak.jpg";
import dessertImage from "@/assets/dish-dessert.jpg";

const Menu = () => {
  const dishes = [
    {
      name: "Truffle Pasta",
      description: "Handmade pasta with black truffle, parmesan, and fresh herbs",
      price: "$32",
      image: pastaImage,
    },
    {
      name: "Prime Ribeye",
      description: "28-day aged ribeye with roasted vegetables and red wine reduction",
      price: "$58",
      image: steakImage,
    },
    {
      name: "Chocolate Soufflé",
      description: "Dark chocolate soufflé with gold leaf and vanilla bean gelato",
      price: "$18",
      image: dessertImage,
    },
  ];

  return (
    <section id="menu" className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="max-w-3xl mx-auto text-center mb-16 animate-in fade-in duration-700">
          <h2 className="text-4xl md:text-5xl font-bold text-foreground mb-6">
            Our Signature Dishes
          </h2>
          <p className="text-lg text-muted-foreground">
            Explore our carefully curated selection of culinary masterpieces
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {dishes.map((dish, index) => (
            <Card 
              key={index} 
              className="overflow-hidden hover:shadow-glow transition-all duration-300 animate-in slide-in-from-bottom-4 duration-700 group"
              style={{ animationDelay: `${index * 150}ms` }}
            >
              <div className="relative h-64 overflow-hidden">
                <img 
                  src={dish.image} 
                  alt={dish.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-secondary/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
              </div>
              <CardContent className="p-6">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="text-2xl font-semibold">{dish.name}</h3>
                  <span className="text-xl font-bold text-primary">{dish.price}</span>
                </div>
                <p className="text-muted-foreground">{dish.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Menu;
