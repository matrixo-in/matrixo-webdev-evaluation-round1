import { Button } from "@/components/ui/button";
import heroImage from "@/assets/hero-restaurant.jpg";

const Hero = () => {
  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section id="home" className="relative h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div 
        className="absolute inset-0 bg-cover bg-center"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-gradient-hero opacity-80" />
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 animate-in fade-in duration-1000">
        <h1 className="text-5xl md:text-7xl font-bold text-background mb-6 animate-in slide-in-from-bottom-4 duration-700">
          Experience Fine Dining
        </h1>
        <p className="text-xl md:text-2xl text-background/90 mb-8 max-w-2xl mx-auto animate-in slide-in-from-bottom-4 duration-700 delay-200">
          Where culinary artistry meets unforgettable ambiance
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center animate-in slide-in-from-bottom-4 duration-700 delay-300">
          <Button variant="hero" onClick={() => scrollToSection("menu")}>
            View Menu
          </Button>
          <Button variant="secondary" size="lg" onClick={() => scrollToSection("contact")}>
            Reserve Table
          </Button>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <div className="w-6 h-10 border-2 border-background/50 rounded-full flex items-start justify-center p-2">
          <div className="w-1 h-3 bg-background/50 rounded-full" />
        </div>
      </div>
    </section>
  );
};

export default Hero;
